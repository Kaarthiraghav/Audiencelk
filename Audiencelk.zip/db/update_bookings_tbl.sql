ALTER TABLE `audiencelk`.`bookings` 
ADD COLUMN `booking_number` VARCHAR(9) NOT NULL;