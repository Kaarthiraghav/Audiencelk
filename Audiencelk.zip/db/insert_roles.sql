INSERT INTO `audiencelk`.`roles` (`id`, `role`) VALUES ('1', 'Admin');
INSERT INTO `audiencelk`.`roles` (`id`, `role`) VALUES ('2', 'Organizer');
INSERT INTO `audiencelk`.`roles` (`id`, `role`) VALUES ('3', 'User');
