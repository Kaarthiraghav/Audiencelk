<?php
// Include configuration for BASE_URL
require_once __DIR__ . '/../config.php';
?>