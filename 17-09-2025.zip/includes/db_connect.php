<?php

if (session_status() === PHP_SESSION_NONE) { 
    session_start(); 
}

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = 'Qwerty@1234';  // Default XAMPP has no password for root user
$DB_NAME = 'audiencelk';


// cpanel

// $DB_HOST = 'sql100.infinityfree.com	';
// $DB_USER = 'if0_39947370';
// $DB_PASS = '5xH4vvEUjb3u';
// $DB_NAME = 'if0_39947370_audiencelk';


$connection = mysqli_connect($DB_HOST,$DB_USER,$DB_PASS,$DB_NAME);

if (!$connection){
    die("Connection Failed");

}
?>