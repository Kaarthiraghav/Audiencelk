<?php

define('BASE_URL', 'http://localhost/AudienceLK/');