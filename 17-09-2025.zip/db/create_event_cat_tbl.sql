CREATE TABLE `event_categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
)
